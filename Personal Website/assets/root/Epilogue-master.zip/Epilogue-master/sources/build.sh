#!/bin/sh
set -e


echo "Build with gftools builder"
gftools builder config.yaml


echo "Complete"
